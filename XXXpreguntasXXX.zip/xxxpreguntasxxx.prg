	
* xxxPREGUNTASXXx.PRG - Optimizado con bucle
CLEAR
@ 2,5 SAY "Vamos a hacer un test de 5 preguntas:"
LOCAL lnPuntos, lnI, lcFile, lcPregunta, lcRespuestaUsuario, lcRightAnswer

* 1. Setup FICHEROP.DBF. Es la tabla para la puntuacion, score
SELECT 1
USE C:\DBASE\FICHEROP.DBF
REPLACE PUNTOS WITH 0
lnPuntos = 0

* 2. Bucle que busca las preguntas en 5 ficheros, cada pregunta en un fichero
FOR lnI = 1 TO 5
    lcFile = "C:\DBASE\PREGUNTA" + ALLTRIM(STR(lnI)) + ".DBF"
    
    IF FILE(lcFile)
        SELECT 9
        USE (lcFile)
        GO TOP
        
        * Obtenermos la info del fichero (DBF fields: LINEA, RESPUESTA) 
        lcRightAnswer = ALLTRIM(UPPER(RESPUESTA))
        lcPregunta = ALLTRIM(LINEA)
        lcRespuestaUsuario = SPACE(1)
        
        * Mostramos la pregunta
        @ (lnI * 4), 5 SAY "Q" + ALLTRIM(STR(lnI)) + ". " + lcPregunta + " (V/F)?: " 
        @ (lnI * 4), 77 GET lcRespuestaUsuario 
        READ
        
        * Validamos respuesta
        IF UPPER(TRIM(lcRespuestaUsuario)) == lcRightAnswer
            @ (lnI * 4) + 2, 5 SAY "Respuesta correcta."
            lnPuntos = lnPuntos + 1
        ELSE
            @ (lnI * 4) + 2, 5 SAY "Respuesta incorrecta."
        ENDIF
        
        USE  && Cerramos fichero en uso
    ENDIF
ENDFOR

* 3. Grabamos puntuacion en FICHEROP.DBF 
SELECT 1
GO TOP
REPLACE PUNTOS WITH lnPuntos
 
lcMessage="Puntos obtenidos: "+ALLTRIM(STR(lnPuntos))
MESSAGEBOX(lcMessage, 64, "Resultado Final")